-- Durable, auditable storage schema. No user-facing write endpoint is exposed
-- until account identity is implemented, so anonymous visitors cannot read or
-- alter another visitor's research records.

CREATE TABLE IF NOT EXISTS market_snapshots (
  id TEXT PRIMARY KEY,
  symbol TEXT NOT NULL,
  interval TEXT NOT NULL,
  source TEXT NOT NULL,
  captured_at INTEGER NOT NULL,
  first_candle_at INTEGER NOT NULL,
  last_candle_at INTEGER NOT NULL,
  candle_count INTEGER NOT NULL,
  checksum TEXT NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_market_snapshots_symbol_interval_time
  ON market_snapshots(symbol, interval, captured_at DESC);

CREATE TABLE IF NOT EXISTS backtest_reports (
  id TEXT PRIMARY KEY,
  owner_id TEXT NOT NULL,
  symbol TEXT NOT NULL,
  interval TEXT NOT NULL,
  source TEXT NOT NULL,
  strategy TEXT NOT NULL,
  settings_json TEXT NOT NULL,
  result_json TEXT NOT NULL,
  data_range_start INTEGER NOT NULL,
  data_range_end INTEGER NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_backtest_reports_owner_created
  ON backtest_reports(owner_id, created_at DESC);

CREATE TABLE IF NOT EXISTS simulated_trade_logs (
  id TEXT PRIMARY KEY,
  owner_id TEXT NOT NULL,
  symbol TEXT NOT NULL,
  side TEXT NOT NULL CHECK (side IN ('long', 'short')),
  event_type TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  occurred_at INTEGER NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_simulated_trade_logs_owner_time
  ON simulated_trade_logs(owner_id, occurred_at DESC);
