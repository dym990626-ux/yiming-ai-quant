import type { BacktestResult, BacktestSettings } from './backtest'
import type { IntervalId, SymbolId } from '../types'

export type SavedReport = { id:string; createdAt:number; symbol:SymbolId; interval:IntervalId; source:string; settings:BacktestSettings; inside:Pick<BacktestResult,'netReturn'|'maxDrawdown'|'winRate'|'profitFactor'|'sharpeRatio'|'totalTrades'>; outsideReturn:number; candleRange:string }
const key='yiming-backtest-reports-v1'
export const readReports=():SavedReport[]=>{try{return JSON.parse(localStorage.getItem(key)??'[]')}catch{return[]}}
export const saveReport=(report:SavedReport)=>localStorage.setItem(key,JSON.stringify([report,...readReports()].slice(0,30)))
export const deleteReport=(id:string)=>localStorage.setItem(key,JSON.stringify(readReports().filter(x=>x.id!==id)))
export const exportReports=()=>{const rows=['created_at,symbol,interval,strategy,source,inside_return,outside_return,max_drawdown,sharpe,trades',...readReports().map(x=>[new Date(x.createdAt).toISOString(),x.symbol,x.interval,x.settings.strategy,x.source,x.inside.netReturn,x.outsideReturn,x.inside.maxDrawdown,x.inside.sharpeRatio,x.inside.totalTrades].join(','))];const url=URL.createObjectURL(new Blob([rows.join('\n')],{type:'text/csv'}));const a=document.createElement('a');a.href=url;a.download='yiming-backtest-reports.csv';a.click();URL.revokeObjectURL(url)}
