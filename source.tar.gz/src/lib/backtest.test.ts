import { describe, expect, it } from 'vitest'
import { runMaCrossBacktest } from './backtest'
const candles=(xs:number[])=>xs.map((close,i)=>({time:i+1,open:close,high:close,low:close,close,volume:1,closed:true}))
const settings={initialCapital:1000,feeRate:0,slippageRate:0,strategy:'ma-cross' as const,interval:'1h' as const}
describe('backtest',()=>{it('rejects too few candles',()=>expect(()=>runMaCrossBacktest(candles(Array(26).fill(1)),settings)).toThrow());it('returns zero without trades',()=>expect(runMaCrossBacktest(candles(Array(30).fill(10)),settings).netReturn).toBe(0));it('uses next open and fees',()=>{const xs=[...Array(25).fill(10),9,20,21,20,10,9];const r=runMaCrossBacktest(candles(xs),{...settings,feeRate:.001,slippageRate:.001});expect(r.trades.length).toBeGreaterThanOrEqual(0);expect(Number.isFinite(r.finalEquity)).toBe(true)})})
