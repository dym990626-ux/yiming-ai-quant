import type { Candle, IntervalId, SymbolId, Ticker } from '../types'

const REST_BASE = 'https://api.binance.com/api/v3'
const WS_BASE = 'wss://stream.binance.com:9443/ws'
const OKX_BASE = 'https://www.okx.com/api/v5/market'

export const symbols: Record<SymbolId, { label: string; name: string }> = {
  BTCUSDT: { label: 'BTC/USDT', name: 'Bitcoin' },
  ETHUSDT: { label: 'ETH/USDT', name: 'Ethereum' },
  SOLUSDT: { label: 'SOL/USDT', name: 'Solana' },
}

export const intervals: { id: IntervalId; label: string }[] = [
  { id: '1m', label: '1分钟' }, { id: '5m', label: '5分钟' }, { id: '15m', label: '15分钟' },
  { id: '1h', label: '1小时' }, { id: '4h', label: '4小时' }, { id: '1d', label: '1天' }, { id: '1w', label: '1周' },
]

async function request<T>(path: string, signal?: AbortSignal): Promise<T> {
  const response = await fetch(`${REST_BASE}${path}`, { signal })
  if (!response.ok) throw new Error(`行情服务响应异常（HTTP ${response.status}）`)
  return response.json() as Promise<T>
}

export async function fetchKlines(symbol: SymbolId, interval: IntervalId, signal?: AbortSignal): Promise<Candle[]> {
  try {
    const data = await request<[number, string, string, string, string, string][]>(`/klines?symbol=${symbol}&interval=${interval}&limit=500`, signal)
    return data.map(([time, open, high, low, close, volume]) => ({ time: Math.floor(time / 1000), open: Number(open), high: Number(high), low: Number(low), close: Number(close), volume: Number(volume) }))
  } catch { return fetchOkxKlines(symbol, interval, signal) }
}

export async function fetchTicker(symbol: SymbolId, signal?: AbortSignal): Promise<Ticker> {
  try { const d = await request<{ lastPrice: string; priceChangePercent: string; highPrice: string; lowPrice: string; volume: string; quoteVolume: string }>(`/ticker/24hr?symbol=${symbol}`, signal); return { price: Number(d.lastPrice), changePercent: Number(d.priceChangePercent), high: Number(d.highPrice), low: Number(d.lowPrice), volume: Number(d.volume), quoteVolume: Number(d.quoteVolume), updatedAt: Date.now(), source: 'Binance' } } catch { return fetchOkxTicker(symbol, signal) }
}

const okxBar: Record<IntervalId, string> = { '1m': '1m', '5m': '5m', '15m': '15m', '1h': '1H', '4h': '4H', '1d': '1D', '1w': '1W' }
const okxId = (symbol: SymbolId) => `${symbol.slice(0, -4)}-USDT`
async function okxRequest<T>(path: string, signal?: AbortSignal): Promise<T> { const response = await fetch(`${OKX_BASE}${path}`, { signal }); if (!response.ok) throw new Error(`备用行情服务响应异常（HTTP ${response.status}）`); return response.json() as Promise<T> }
async function fetchOkxKlines(symbol: SymbolId, interval: IntervalId, signal?: AbortSignal): Promise<Candle[]> { const d = await okxRequest<{ code: string; data: string[][] }>(`/candles?instId=${okxId(symbol)}&bar=${okxBar[interval]}&limit=300`, signal); if (d.code !== '0') throw new Error('OKX 未返回有效 K 线数据'); return d.data.map(([time, open, high, low, close, volume]) => ({ time: Math.floor(Number(time) / 1000), open: Number(open), high: Number(high), low: Number(low), close: Number(close), volume: Number(volume) })).reverse() }
async function fetchOkxTicker(symbol: SymbolId, signal?: AbortSignal): Promise<Ticker> { const d = await okxRequest<{ code: string; data: { last: string; open24h: string; high24h: string; low24h: string; vol24h: string; volCcy24h: string; ts: string }[] }>(`/ticker?instId=${okxId(symbol)}`, signal); const x = d.data[0]; if (d.code !== '0' || !x) throw new Error('OKX 未返回有效行情'); const open = Number(x.open24h); return { price: Number(x.last), changePercent: open ? (Number(x.last) / open - 1) * 100 : 0, high: Number(x.high24h), low: Number(x.low24h), volume: Number(x.vol24h), quoteVolume: Number(x.volCcy24h), updatedAt: Number(x.ts), source: 'OKX（Binance 不可用时自动备用）' } }

export function openTickerSocket(symbol: SymbolId, onTicker: (ticker: Ticker) => void, onOpen: () => void, onClose: () => void, onError: () => void): WebSocket {
  const ws = new WebSocket(`${WS_BASE}/${symbol.toLowerCase()}@ticker`)
  ws.onopen = onOpen
  ws.onerror = onError
  ws.onclose = onClose
  ws.onmessage = (event) => {
    try {
      const d = JSON.parse(event.data) as { c: string; P: string; h: string; l: string; v: string; q: string; E: number }
      onTicker({ price: Number(d.c), changePercent: Number(d.P), high: Number(d.h), low: Number(d.l), volume: Number(d.v), quoteVolume: Number(d.q), updatedAt: d.E, source: 'Binance' })
    } catch { /* Ignore malformed public stream event. */ }
  }
  return ws
}
