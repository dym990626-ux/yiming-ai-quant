import { useEffect, useRef } from 'react'
import { createChart, ColorType, CandlestickSeries, HistogramSeries, LineSeries, type IChartApi, type UTCTimestamp } from 'lightweight-charts'
import type { Candle } from '../types'
import { bollinger, ema, sma } from '../lib/indicators'

function chartPoint<T extends { time: number }>(p: T) { return { ...p, time: p.time as UTCTimestamp } }

export function PriceChart({ candles }: { candles: Candle[] }) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (!ref.current || candles.length === 0) return
    const chart: IChartApi = createChart(ref.current, { layout: { background: { type: ColorType.Solid, color: '#ffffff' }, textColor: '#667085', fontFamily: 'Inter, ui-sans-serif, system-ui', fontSize: 12 }, grid: { vertLines: { color: '#f2f4f7' }, horzLines: { color: '#f2f4f7' } }, rightPriceScale: { borderColor: '#eaecf0' }, timeScale: { borderColor: '#eaecf0', timeVisible: true, secondsVisible: false }, crosshair: { vertLine: { color: '#98a2b3', labelBackgroundColor: '#344054' }, horzLine: { color: '#98a2b3', labelBackgroundColor: '#344054' } }, height: Math.max(360, ref.current.clientHeight) })
    const candleSeries = chart.addSeries(CandlestickSeries, { upColor: '#12b76a', downColor: '#f04438', borderVisible: false, wickUpColor: '#12b76a', wickDownColor: '#f04438' })
    candleSeries.setData(candles.map(c => ({ ...chartPoint(c), open: c.open, high: c.high, low: c.low, close: c.close })))
    const volume = chart.addSeries(HistogramSeries, { priceFormat: { type: 'volume' }, priceScaleId: '', lastValueVisible: false, priceLineVisible: false })
    volume.priceScale().applyOptions({ scaleMargins: { top: 0.78, bottom: 0 } })
    volume.setData(candles.map(c => ({ time: c.time as UTCTimestamp, value: c.volume, color: c.close >= c.open ? 'rgba(18,183,106,.35)' : 'rgba(240,68,56,.35)' })))
    const addLine = (data: { time: number; value: number }[], color: string, width: 1 | 2 | 3 | 4 = 1) => { const s = chart.addSeries(LineSeries, { color, lineWidth: width, lastValueVisible: false, priceLineVisible: false }); s.setData(data.map(chartPoint)); }
    addLine(sma(candles, 7), '#f79009'); addLine(sma(candles, 25), '#1570ef'); addLine(sma(candles, 99), '#7a5af8'); addLine(ema(candles, 12), '#ee46bc'); addLine(ema(candles, 26), '#0ba5ec');
    const bb = bollinger(candles); addLine(bb.upper, '#98a2b3'); addLine(bb.middle, '#98a2b3'); addLine(bb.lower, '#98a2b3')
    chart.timeScale().fitContent()
    const observer = new ResizeObserver(() => chart.applyOptions({ width: ref.current?.clientWidth ?? 0 }))
    observer.observe(ref.current); return () => { observer.disconnect(); chart.remove() }
  }, [candles])
  return <div className="chart" ref={ref} />
}
