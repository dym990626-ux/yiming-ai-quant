type QueryResult<T> = { results: T[] }

type D1Statement = {
  all<T>(): Promise<QueryResult<T>>
}

type D1Database = {
  prepare(query: string): D1Statement
}

type AssetBinding = {
  fetch(request: Request): Promise<Response>
}

type Env = {
  ASSETS: AssetBinding
  DB: D1Database
}

type SchemaRow = { name: string }

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
  },
})

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url)

    if (url.pathname === '/api/health') {
      if (request.method !== 'GET') return json({ error: 'Method not allowed' }, 405)

      try {
        const tables = await env.DB
          .prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' ORDER BY name")
          .all<SchemaRow>()

        return json({
          ok: true,
          service: 'yiming-ai-quant',
          database: 'connected',
          tables: tables.results.map((table) => table.name),
          checkedAt: new Date().toISOString(),
        })
      } catch (error) {
        return json({
          ok: false,
          service: 'yiming-ai-quant',
          database: 'unavailable',
          error: error instanceof Error ? error.message : 'Unknown database error',
          checkedAt: new Date().toISOString(),
        }, 503)
      }
    }

    if (url.pathname.startsWith('/api/')) return json({ error: 'Not found' }, 404)
    return env.ASSETS.fetch(request)
  },
}
