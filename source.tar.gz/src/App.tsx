import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { PriceChart } from './components/PriceChart'
import { BacktestPage } from './components/BacktestPage'
import { SimTradePage } from './components/SimTradePage'
import { ResearchPage } from './components/ResearchPage'
import { fetchKlines, fetchTicker, intervals, openTickerSocket, symbols } from './lib/market'
import { macd, rsi } from './lib/indicators'
import type { Candle, ConnectionState, IntervalId, SymbolId, Ticker } from './types'

const formatPrice = (n: number) => new Intl.NumberFormat('en-US', { maximumFractionDigits: n >= 100 ? 2 : n >= 1 ? 4 : 6 }).format(n)
const formatCompact = (n: number) => new Intl.NumberFormat('en-US', { notation: 'compact', maximumFractionDigits: 2 }).format(n)
const formatTime = (time?: number) => time ? new Intl.DateTimeFormat('zh-CN', { hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(time) : '—'

function PlaceholderPage({ title, description }: { title: string; description: string }) { return <main className="placeholder"><div className="eyebrow">V1.0 预留模块</div><h1>{title}</h1><p>{description}</p><div className="empty-card">该模块尚未配置分析逻辑或真实历史数据，因此不会展示任何 AI 结论、策略信号或绩效数字。</div></main> }

export default function App() {
  const [page, setPage] = useState('行情中心'), [symbol, setSymbol] = useState<SymbolId>('BTCUSDT'), [interval, setInterval] = useState<IntervalId>('1h')
  const [candles, setCandles] = useState<Candle[]>([]), [ticker, setTicker] = useState<Ticker | null>(null), [status, setStatus] = useState<ConnectionState>('loading'), [error, setError] = useState<string | null>(null)
  const reconnect = useRef<ReturnType<typeof setTimeout> | null>(null), attempts = useRef(0)
  const load = useCallback(async (signal?: AbortSignal) => { setError(null); setCandles([]); setTicker(null); setStatus('loading'); try { const [nextCandles, nextTicker] = await Promise.all([fetchKlines(symbol, interval, signal), fetchTicker(symbol, signal)]); setCandles(nextCandles); setTicker(nextTicker); setStatus('reconnecting') } catch (e) { if (!signal?.aborted) { setError(e instanceof Error ? e.message : '无法加载公开行情'); setStatus('error') } } }, [symbol, interval])
  useEffect(() => { const controller = new AbortController(); void load(controller.signal); return () => controller.abort() }, [load])
  useEffect(() => { let ws: WebSocket | null = null, active = true
    const connect = () => { if (!active) return; ws = openTickerSocket(symbol, t => { attempts.current = 0; setTicker(t); setStatus('connected') }, () => { attempts.current = 0; setStatus('connected') }, () => { if (!active) return; setStatus('stale'); const wait = Math.min(30_000, 1000 * 2 ** attempts.current++); reconnect.current = setTimeout(connect, wait) }, () => setStatus('stale')) }
    if (ticker?.source?.startsWith('OKX')) { setStatus('connected'); const poll = window.setInterval(() => { void fetchTicker(symbol).then(setTicker).catch(() => setStatus('stale')) }, 10_000); return () => window.clearInterval(poll) }
    connect(); return () => { active = false; if (reconnect.current) clearTimeout(reconnect.current); ws?.close() }
  }, [symbol, ticker?.source])
  const analysis = useMemo(() => ({ rsi: rsi(candles).at(-1)?.value, macd: macd(candles).macd.at(-1)?.value }), [candles])
  const up = (ticker?.changePercent ?? 0) >= 0
  const nav = ['行情中心', '六 AI 研究', '历史回测', '模拟交易', '设置']
  if (page !== '行情中心') return <><header className="topbar"><button className="brand" onClick={() => setPage('行情中心')}><span className="brand-mark">Y</span><span>一鸣 AI Quant</span></button><nav>{nav.map(x => <button className={page === x ? 'active' : ''} onClick={() => setPage(x)} key={x}>{x}</button>)}</nav></header>{page === '历史回测' ? <BacktestPage /> : page === '模拟交易' ? <SimTradePage symbol={symbol} ticker={ticker} /> : page === '六 AI 研究' ? <ResearchPage candles={candles} ticker={ticker} /> : <PlaceholderPage title={page} description={`${page} 将在后续阶段基于真实历史行情和明确规则实现。`} />}</>
  return <div className="app"><header className="topbar"><button className="brand"><span className="brand-mark">Y</span><span>一鸣 AI Quant</span></button><nav>{nav.map(x => <button className={page === x ? 'active' : ''} onClick={() => setPage(x)} key={x}>{x}</button>)}</nav><div className={`connection ${status}`}><i />{status === 'connected' ? '实时连接' : status === 'loading' ? '加载中' : status === 'reconnecting' ? '等待实时流' : status === 'stale' ? '数据已过期 · 重连中' : '连接异常'}</div></header>
  <div className="terminal"><aside className="symbols"><div className="section-label">交易品种 <span>USDT</span></div>{(Object.keys(symbols) as SymbolId[]).map(id => <button key={id} onClick={() => setSymbol(id)} className={`symbol ${symbol === id ? 'selected' : ''}`}><b>{symbols[id].label}</b><small>{symbols[id].name}</small>{id === symbol && ticker && <em className={ticker.changePercent >= 0 ? 'positive' : 'negative'}>{ticker.changePercent >= 0 ? '+' : ''}{ticker.changePercent.toFixed(2)}%</em>}</button>)}<div className="source-note">数据来源<br/><b>{ticker?.source ?? '连接中'}</b><br/>现货 · 公开 REST / WebSocket</div></aside>
  <main className="market"><section className="quote"><div><span className="pair">{symbols[symbol].label}</span><span className="exchange">{ticker?.source ? `${ticker.source} · SPOT` : '数据源连接中'}</span><h1 className={up ? 'positive' : 'negative'}>{ticker ? formatPrice(ticker.price) : '—'} <small>USDT</small></h1><p className={up ? 'positive' : 'negative'}>{ticker ? `${up ? '+' : ''}${ticker.changePercent.toFixed(2)}%` : '等待真实数据'}</p></div><div className="quote-stats"><Stat label="24h 最高" value={ticker ? formatPrice(ticker.high) : '—'} /><Stat label="24h 最低" value={ticker ? formatPrice(ticker.low) : '—'} /><Stat label="24h 成交量" value={ticker ? formatCompact(ticker.volume) : '—'} /><Stat label="24h 成交额" value={ticker ? `${formatCompact(ticker.quoteVolume)} USDT` : '—'} /></div></section>
  <section className="chart-panel"><div className="periods">{intervals.map(x => <button onClick={() => setInterval(x.id)} className={interval === x.id ? 'active' : ''} key={x.id}>{x.label}</button>)}<span className="chart-legend"><i className="ma7"/>MA7 <i className="ma25"/>MA25 <i className="ma99"/>MA99</span></div>{error ? <div className="data-error"><b>无法获取真实行情</b><p>{error}</p><button onClick={() => void load()}>重新加载</button></div> : candles.length ? <PriceChart candles={candles} /> : <div className="loading">正在请求公开交易所 K 线…</div>}</section>
  <section className="indicator-strip"><Indicator label="RSI (14)" value={analysis.rsi?.toFixed(2) ?? '—'} /><Indicator label="MACD (12, 26, 9)" value={analysis.macd?.toFixed(4) ?? '—'} /><Indicator label="布林带" value="20 / 2" /><Indicator label="成交量" value={candles.at(-1) ? formatCompact(candles.at(-1)!.volume) : '—'} /></section></main>
  <aside className="research"><div className="panel-title">研究面板 <span>V1.0</span></div>{['趋势分析', '资金分析', '波动分析', '风险分析', '策略分析', '综合决策'].map((x, i) => <div className="research-item" key={x}><div className="research-icon">0{i + 1}</div><div><b>{x}</b><p>等待独立模型与真实证据配置</p></div><span>—</span></div>)}<div className="research-disclaimer">当前未启用 AI 分析。平台不会展示未经数据和规则支持的结论。</div></aside></div>
  <footer><span>技术指标：MA / EMA / RSI / MACD / Bollinger / Volume</span><span>行情更新时间：{formatTime(ticker?.updatedAt)}</span><span className={status === 'connected' ? 'positive' : 'negative'}>{status === 'connected' ? '● 数据流正常' : '● 数据非实时'}</span></footer></div>
}
function Stat({ label, value }: { label: string; value: string }) { return <div><span>{label}</span><b>{value}</b></div> }
function Indicator({ label, value }: { label: string; value: string }) { return <div><span>{label}</span><b>{value}</b></div> }
